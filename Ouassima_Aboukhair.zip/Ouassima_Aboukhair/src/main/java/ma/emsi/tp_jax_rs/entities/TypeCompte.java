package ma.emsi.tp_jax_rs.entities;
public enum TypeCompte {
    COURANT,EPARGNE ;
}