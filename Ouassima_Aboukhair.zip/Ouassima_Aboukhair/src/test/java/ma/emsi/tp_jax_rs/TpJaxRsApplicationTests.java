package ma.emsi.tp_jax_rs;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpJaxRsApplicationTests {

    @Test
    void contextLoads() {
    }

}